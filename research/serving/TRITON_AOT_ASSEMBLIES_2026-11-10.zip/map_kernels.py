import triton
import triton.language as tl

@triton.jit
def _map_kernel(ids, mapping, out, N: tl.constexpr, BLOCK: tl.constexpr):
    offset = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    live = offset < N
    # Match the original cast before indexing, including int64 wraparound.
    expert = tl.load(ids + offset, live, other=-1).to(tl.int32)
    mapped = tl.load(mapping + expert, live & (expert >= 0), other=-1)
    tl.store(out + offset, mapped, live)
