import triton
import triton.language as tl

@triton.jit
def _pack(values, ids, packed, size: tl.constexpr, columns: tl.constexpr,
          vs0: tl.constexpr, vs1: tl.constexpr, is0: tl.constexpr,
          is1: tl.constexpr, start: tl.constexpr, BLOCK: tl.constexpr):
    pos = tl.program_id(0)*BLOCK + tl.arange(0, BLOCK)
    row, col = pos//columns, pos % columns
    value = tl.load(values+row*vs0+col*vs1, pos < size, other=0).to(tl.float32)
    index = tl.load(ids+row*is0+col*is1, pos < size, other=0).to(tl.int64)
    bits = value.to(tl.uint32, bitcast=True).to(tl.uint64)
    pair = ((index+start).to(tl.uint64) << 32) | bits
    tl.store(packed+pos, pair.to(tl.int64), pos < size)


@triton.jit
def _unpack(packed, values, ids, size: tl.constexpr, columns: tl.constexpr,
            ps0: tl.constexpr, ps1: tl.constexpr, BLOCK: tl.constexpr):
    pos = tl.program_id(0)*BLOCK + tl.arange(0, BLOCK)
    row, col = pos//columns, pos % columns
    pair = tl.load(packed+row*ps0+col*ps1, pos < size, other=0).to(tl.uint64)
    bits = pair.to(tl.uint32)
    tl.store(values+pos, bits.to(tl.float32, bitcast=True), pos < size)
    tl.store(ids+pos, (pair >> 32).to(tl.int64), pos < size)
