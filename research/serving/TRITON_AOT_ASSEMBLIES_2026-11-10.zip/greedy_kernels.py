import triton
import triton.language as tl

@triton.jit
def _pack_greedy_pairs(
    values,
    indices,
    pairs,
    n: tl.constexpr,
    vocab_start: tl.constexpr,
    BLOCK: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    value = tl.load(values + offsets, offsets < n, other=0).to(tl.float32)
    index = tl.load(indices + offsets, offsets < n, other=0).to(tl.int64)
    # FP16/BF16 -> FP32 is lossless. Transport the bits, without quantization
    # or floating-point conversion of the potentially large token IDs.
    bits = value.to(tl.int32, bitcast=True).to(tl.int64)
    tl.store(pairs + 2 * offsets, bits, offsets < n)
    tl.store(pairs + 2 * offsets + 1, index + vocab_start, offsets < n)


@triton.jit
def _select_greedy_pairs(
    gathered,
    output,
    n: tl.constexpr,
    tp_size: tl.constexpr,
    RANKS: tl.constexpr,
    BLOCK: tl.constexpr,
):
    offsets = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    ranks = tl.arange(0, RANKS)
    valid = (ranks[:, None] < tp_size) & (offsets[None, :] < n)
    address = (ranks[:, None] * n + offsets[None, :]) * 2
    bits = tl.load(gathered + address, valid, other=0).to(tl.int32)
    values = bits.to(tl.float32, bitcast=True)
    is_nan = valid & (values != values)
    has_nan = tl.max(is_nan.to(tl.int32), axis=0) != 0
    maximum = tl.max(tl.where(valid & ~is_nan, values, -float("inf")), axis=0)
    # Match torch.argmax: first NaN, otherwise first maximum. Rank order,
    # rather than token-ID order, preserves the existing sampler's tie rule.
    matches = valid & tl.where(has_nan[None, :], is_nan, values == maximum[None, :])
    rank = tl.min(tl.where(matches, ranks[:, None], RANKS), axis=0)
    token = tl.load(gathered + (rank * n + offsets) * 2 + 1, offsets < n, other=0)
    tl.store(output + offsets, token, offsets < n)
